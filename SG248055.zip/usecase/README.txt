The materials presented in this ZIP file is to be used with the following IBM Redbooks publication:
Customizing and Extending IBM Content Navigator, SG24-8055


Disclaimer 
==============
IBM does not warrant or represent that the material in this ZIP file is complete or up-to-date. 
IBM does not warrant, represent or imply reliability, serviceability or function of the code 
presented in association with the book. IBM is under no obligation to update content nor provide 
further support. 

All code is provided "as is," with no warranties or guarantees whatsoever. 
IBM expressly disclaims to the fullest extent permitted by law all express, implied, statutory 
and other warranties, guarantees, or representations, including, without limitation, 
the warranties of merchantability, fitness for a particular purpose, and non-infringement 
of proprietary and intellectual property rights. You understand and agree that you use these 
materials, information, products, software, programs, and services, at your own discretion and 
risk and that you will be solely responsible for any damages that may result, including loss 
of data or damage to your computer system.

In no event will IBM be liable to any party for any direct, indirect, incidental, special, 
exemplary or consequential damages of any type whatsoever related to or arising from use of the 
code found herein, without limitation, any lost profits, business interruption, lost savings, 
loss of programs or other data, even if ibm is expressly advised of the possibility of such damages. 
this exclusion and waiver of liability applies to all causes of action, whether based on contract, 
warranty, tort or any other legal theories.

